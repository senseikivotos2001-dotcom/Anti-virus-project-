# LegacyDefender

All-in-one security app for Android ≤12. Can escalate privileges (root) via exploits and perform deep system scan.

## Features
- Root detection and privilege escalation (CVE exploits)
- Process and memory scanning (when root available)
- File-based malware detection (no root required)
- Malware detection heuristics
- No-root fallback mode using VPNService (coming soon)

## Building
1. Open in Android Studio
2. Build → Build APK

## Download
APK available in Releases (not on Play Store).

## Disclaimer
This app contains exploits for educational purposes. Use at your own risk.