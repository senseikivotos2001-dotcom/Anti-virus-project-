package com.legacydefender.root

import android.content.Context
import com.legacydefender.native.NativeBridge

object RootManager {
    private var _hasRoot = false

    fun hasRoot(context: Context): Boolean {
        if (_hasRoot) return true

        // Kiểm tra su thông thường
        _hasRoot = NativeBridge.checkSu()
        if (_hasRoot) return true

        // Thử khai thác CVE
        _hasRoot = ExploitManager.tryExploit(context)
        
        // Xác minh lần cuối
        if (_hasRoot) {
            val test = NativeBridge.executeRootCommand("echo root")
            _hasRoot = test?.contains("root") == true
        }
        return _hasRoot
    }

    fun executeCommand(cmd: String): String? {
        return if (_hasRoot) NativeBridge.executeRootCommand(cmd)
        else NativeBridge.executeShellCommand(cmd)
    }

    fun killProcess(pid: Int): Boolean {
        return if (_hasRoot) {
            executeCommand("kill -9 $pid") != null
        } else false
    }

    fun uninstallPackage(pkgName: String): Boolean {
        return if (_hasRoot) {
            executeCommand("pm uninstall $pkgName") != null
        } else false
    }
}