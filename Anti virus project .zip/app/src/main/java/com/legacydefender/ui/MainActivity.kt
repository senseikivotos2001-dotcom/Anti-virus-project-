package com.legacydefender.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.legacydefender.R
import com.legacydefender.root.RootManager
import com.legacydefender.scanner.ProcScanner
import com.legacydefender.scanner.MemScanner
import com.legacydefender.scanner.FileScanner

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var resultText: TextView
    private lateinit var btnScanProc: Button
    private lateinit var btnScanMem: Button
    private lateinit var btnScanFile: Button

    companion object {
        private const val REQUEST_CODE_STORAGE = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        resultText = findViewById(R.id.resultText)
        btnScanProc = findViewById(R.id.btnScanProc)
        btnScanMem = findViewById(R.id.btnScanMem)
        btnScanFile = findViewById(R.id.btnScanFile)

        checkRootAndUpdateStatus()

        btnScanProc.setOnClickListener {
            if (RootManager.hasRoot(this)) {
                val processes = ProcScanner.scanProcesses()
                resultText.text = "Processes:\n" + processes.joinToString("\n")
            } else {
                Toast.makeText(this, "Need root for process scan", Toast.LENGTH_SHORT).show()
            }
        }

        btnScanMem.setOnClickListener {
            if (RootManager.hasRoot(this)) {
                val suspicious = MemScanner.scanSuspiciousMemory()
                resultText.text = "Suspicious memory regions:\n" +
                        suspicious.joinToString("\n") {
                            "PID ${it.pid}: ${it.start}-${it.end} ${it.permissions} ${it.pathname}"
                        }
            } else {
                Toast.makeText(this, "Need root for memory scan", Toast.LENGTH_SHORT).show()
            }
        }

        btnScanFile.setOnClickListener {
            if (checkStoragePermission()) {
                val suspiciousFiles = FileScanner.scanStorage(this)
                resultText.text = "Suspicious files:\n" +
                        suspiciousFiles.joinToString("\n") {
                            "${it.path} (${it.size} bytes)"
                        }
            } else {
                requestStoragePermission()
            }
        }
    }

    private fun checkRootAndUpdateStatus() {
        val hasRoot = RootManager.hasRoot(this)
        statusText.text = if (hasRoot) "✅ Root available" else "❌ No root (limited mode)"
    }

    private fun checkStoragePermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
    }

    private fun requestStoragePermission() {
        ActivityCompat.requestPermissions(this,
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
            REQUEST_CODE_STORAGE)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_STORAGE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Storage permission granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Storage permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }
}