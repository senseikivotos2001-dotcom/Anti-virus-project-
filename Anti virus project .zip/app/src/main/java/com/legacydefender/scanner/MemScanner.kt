package com.legacydefender.scanner

import com.legacydefender.native.NativeBridge
import com.legacydefender.root.RootManager

data class MemoryRegion(
    val pid: Int,
    val start: Long,
    val end: Long,
    val permissions: String,
    val pathname: String
)

object MemScanner {

    fun scanSuspiciousMemory(): List<MemoryRegion> {
        if (!RootManager.hasRoot()) {
            return emptyList()
        }

        val result = mutableListOf<MemoryRegion>()
        val processList = ProcScanner.scanProcesses().mapNotNull { line ->
            line.substringBefore(':').toIntOrNull()
        }

        for (pid in processList) {
            val regions = getMemoryRegions(pid)
            result.addAll(regions.filter { isSuspicious(it) })
        }
        return result
    }

    fun getMemoryRegions(pid: Int): List<MemoryRegion> {
        val output = NativeBridge.getMemoryMaps(pid) ?: return emptyList()
        return parseMapsOutput(pid, output)
    }

    private fun parseMapsOutput(pid: Int, maps: String): List<MemoryRegion> {
        val regions = mutableListOf<MemoryRegion>()
        val lines = maps.split("\n")

        for (line in lines) {
            if (line.isBlank()) continue

            val parts = line.split(" ", limit = 6)
            if (parts.size < 5) continue

            val addrRange = parts[0].split("-")
            if (addrRange.size != 2) continue

            val start = addrRange[0].toLongOrNull(16) ?: 0
            val end = addrRange[1].toLongOrNull(16) ?: 0
            val perms = parts[1]
            val pathname = if (parts.size > 5) parts[5] else ""

            regions.add(MemoryRegion(pid, start, end, perms, pathname))
        }
        return regions
    }

    private fun isSuspicious(region: MemoryRegion): Boolean {
        val hasRwx = region.permissions.contains("rwx")
        val noFile = region.pathname.isEmpty() ||
                region.pathname.contains("[anon") ||
                region.pathname.contains("memfd:")
        return hasRwx && noFile
    }
}