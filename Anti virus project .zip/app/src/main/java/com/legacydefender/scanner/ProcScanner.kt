package com.legacydefender.scanner

import com.legacydefender.native.NativeBridge

object ProcScanner {
    fun scanProcesses(): List<String> {
        val output = NativeBridge.getProcessList()
        return output?.split("\n")?.filter { it.isNotBlank() } ?: emptyList()
    }
}