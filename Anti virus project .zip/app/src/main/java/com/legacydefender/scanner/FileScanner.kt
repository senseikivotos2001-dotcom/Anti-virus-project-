package com.legacydefender.scanner

import android.content.Context
import android.os.Environment
import java.io.File

data class SuspiciousFile(
    val path: String,
    val size: Long,
    val lastModified: Long
)

object FileScanner {

    fun scanStorage(context: Context): List<SuspiciousFile> {
        val result = mutableListOf<SuspiciousFile>()
        val storageDir = Environment.getExternalStorageDirectory()
        if (storageDir.exists()) {
            scanDirectory(storageDir, result)
        }
        return result
    }

    private fun scanDirectory(dir: File, result: MutableList<SuspiciousFile>) {
        val files = dir.listFiles() ?: return
        for (file in files) {
            if (file.isDirectory) {
                // Skip Android/data and Android/obb because we can't access them without root
                if (file.name == "Android") {
                    // Optionally scan subdirs? But they are protected.
                    // For simplicity, skip entire Android folder.
                    continue
                }
                scanDirectory(file, result)
            } else {
                if (isSuspicious(file)) {
                    result.add(SuspiciousFile(file.absolutePath, file.length(), file.lastModified()))
                }
            }
        }
    }

    private fun isSuspicious(file: File): Boolean {
        val name = file.name.lowercase()
        // Heuristics:
        // 1. Hidden .apk file
        if (name.endsWith(".apk") && file.isHidden) return true
        // 2. .dex file in cache-like paths
        if (name.endsWith(".dex") && file.parent?.contains("cache") == true) return true
        // 3. Executable .so outside lib folder
        if (name.endsWith(".so") && !file.parent?.contains("lib") == true) return true
        // 4. Obfuscated script names
        if (name.endsWith(".sh") && file.parent?.contains("Download") == true) return true
        return false
    }
}