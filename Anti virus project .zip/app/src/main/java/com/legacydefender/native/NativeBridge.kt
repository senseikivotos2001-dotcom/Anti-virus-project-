package com.legacydefender.native

object NativeBridge {
    init {
        System.loadLibrary("native-lib")
    }

    external fun checkSu(): Boolean
    external fun executeRootCommand(cmd: String): String?
    external fun executeShellCommand(cmd: String): String?
    external fun runExploit(name: String): Boolean
    external fun getProcessList(): String?
    external fun getMemoryMaps(pid: Int): String?
    external fun runExploitBinary(execPath: String): Boolean  // <--- THÊM DÒNG NÀY
}