#include <jni.h>
#include <unistd.h>

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_legacydefender_native_NativeBridge_isRoot(JNIEnv *env, jobject /* this */) {
    return getuid() == 0 ? JNI_TRUE : JNI_FALSE;
}

}