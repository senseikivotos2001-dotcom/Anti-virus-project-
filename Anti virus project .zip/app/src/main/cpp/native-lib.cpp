#include <jni.h>
#include <string>
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <unistd.h>

extern "C" {

// Check su
JNIEXPORT jboolean JNICALL
Java_com_legacydefender_native_NativeBridge_checkSu(JNIEnv *env, jobject /* this */) {
    int status = system("su -c 'echo root' > /dev/null 2>&1");
    return status == 0 ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT jboolean JNICALL
Java_com_legacydefender_native_NativeBridge_runExploitBinary(JNIEnv *env, jobject /* this */, jstring execPath) {
    const char* path = env->GetStringUTFChars(execPath, nullptr);
    
    // Thực thi binary, đợi kết quả
    int status = system(path);
    
    env->ReleaseStringUTFChars(execPath, path);
    
    // Nếu binary trả về 0 (thành công) thì coi như root thành công
    return (status == 0) ? JNI_TRUE : JNI_FALSE;
}
// Execute command with root
JNIEXPORT jstring JNICALL
Java_com_legacydefender_native_NativeBridge_executeRootCommand(JNIEnv *env, jobject /* this */, jstring cmd) {
    const char* cmdStr = env->GetStringUTFChars(cmd, nullptr);
    std::string fullCmd = "su -c '" + std::string(cmdStr) + "' 2>&1";
    FILE* pipe = popen(fullCmd.c_str(), "r");
    if (!pipe) return nullptr;
    char buffer[128];
    std::string result;
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        result += buffer;
    }
    pclose(pipe);
    env->ReleaseStringUTFChars(cmd, cmdStr);
    return env->NewStringUTF(result.c_str());
}

// Execute command without root (shell)
JNIEXPORT jstring JNICALL
Java_com_legacydefender_native_NativeBridge_executeShellCommand(JNIEnv *env, jobject /* this */, jstring cmd) {
    const char* cmdStr = env->GetStringUTFChars(cmd, nullptr);
    FILE* pipe = popen(cmdStr, "r");
    if (!pipe) return nullptr;
    char buffer[128];
    std::string result;
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        result += buffer;
    }
    pclose(pipe);
    env->ReleaseStringUTFChars(cmd, cmdStr);
    return env->NewStringUTF(result.c_str());
}

// Run exploit (placeholder)
JNIEXPORT jboolean JNICALL
Java_com_legacydefender_native_NativeBridge_runExploit(JNIEnv *env, jobject /* this */, jstring name) {
    const char* nameStr = env->GetStringUTFChars(name, nullptr);
    // Placeholder: actual exploit code would be called here
    bool success = false;
    env->ReleaseStringUTFChars(name, nameStr);
    return success ? JNI_TRUE : JNI_FALSE;
}

// Get memory maps for a PID
JNIEXPORT jstring JNICALL
Java_com_legacydefender_native_NativeBridge_getMemoryMaps(JNIEnv *env, jobject /* this */, jint pid) {
    std::string path = "/proc/" + std::to_string(pid) + "/maps";
    FILE* f = fopen(path.c_str(), "r");
    if (!f) return env->NewStringUTF("");

    char line[256];
    std::string result;
    while (fgets(line, sizeof(line), f)) {
        result += line;
    }
    fclose(f);
    return env->NewStringUTF(result.c_str());
}

// getProcessList implemented in proc_scanner.cpp
// (function declaration there)

} // extern "C"