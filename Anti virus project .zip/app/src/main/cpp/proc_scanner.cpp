#include <jni.h>
#include <string>
#include <vector>
#include <dirent.h>
#include <cstring>

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_legacydefender_native_NativeBridge_getProcessList(JNIEnv *env, jobject /* this */) {
    std::string result;
    DIR* dir = opendir("/proc");
    if (!dir) return env->NewStringUTF("");

    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        if (entry->d_type == DT_DIR) {
            char* endptr;
            int pid = strtol(entry->d_name, &endptr, 10);
            if (*endptr == '\0') {
                char cmdline[256];
                std::string path = "/proc/" + std::string(entry->d_name) + "/cmdline";
                FILE* f = fopen(path.c_str(), "r");
                if (f) {
                    size_t n = fread(cmdline, 1, sizeof(cmdline) - 1, f);
                    if (n > 0) {
                        cmdline[n] = '\0';
                        result += std::string(entry->d_name) + ":" + std::string(cmdline) + "\n";
                    }
                    fclose(f);
                }
            }
        }
    }
    closedir(dir);
    return env->NewStringUTF(result.c_str());
}

}